const Scheme = require("../models/Scheme");


// =======================
// Create Scheme
// =======================
exports.createScheme = async (req, res) => {
  try {
    const {
      name,
      amount,
      durationMonths,
      userPayMonths,
      companyPayMonths,
      monthlyAmount,
      description
    } = req.body;

    // Check duplicate scheme name
    const existingScheme = await Scheme.findOne({ name });

    if (existingScheme) {
      return res.status(400).json({
        success: false,
        message: "Scheme already exists"
      });
    }

    const scheme = await Scheme.create({
      name,
      amount,
      durationMonths,
      userPayMonths,
      companyPayMonths,
      monthlyAmount,
      description
    });

    res.status(201).json({
      success: true,
      message: "Scheme created successfully",
      data: scheme
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};



// =======================
// Get All Schemes
// =======================
exports.getAllSchemes = async (req, res) => {
  try {

    const schemes = await Scheme.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: schemes.length,
      data: schemes
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};



// =======================
// Get Scheme By Id
// =======================
exports.getSchemeById = async (req, res) => {
  try {

    const scheme = await Scheme.findById(req.params.id);

    if (!scheme) {
      return res.status(404).json({
        success: false,
        message: "Scheme not found"
      });
    }

    res.status(200).json({
      success: true,
      data: scheme
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};



// =======================
// Update Scheme
// =======================
exports.updateScheme = async (req, res) => {
  try {

    const scheme = await Scheme.findById(req.params.id);

    if (!scheme) {
      return res.status(404).json({
        success: false,
        message: "Scheme not found"
      });
    }

    const updatedScheme = await Scheme.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true
      }
    );

    res.status(200).json({
      success: true,
      message: "Scheme updated successfully",
      data: updatedScheme
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};



// =======================
// Delete Scheme
// =======================
exports.deleteScheme = async (req, res) => {
  try {

    const scheme = await Scheme.findById(req.params.id);

    if (!scheme) {
      return res.status(404).json({
        success: false,
        message: "Scheme not found"
      });
    }

    await Scheme.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: "Scheme deleted successfully"
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};



// =======================
// Update Status (Active/Inactive)
// =======================
exports.updateSchemeStatus = async (req, res) => {
  try {

    const { isActive } = req.body;

    const scheme = await Scheme.findById(req.params.id);

    if (!scheme) {
      return res.status(404).json({
        success: false,
        message: "Scheme not found"
      });
    }

    scheme.isActive = isActive;

    await scheme.save();

    res.status(200).json({
      success: true,
      message: `Scheme ${isActive ? "Activated" : "Deactivated"} successfully`,
      data: scheme
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message
    });
  }
};