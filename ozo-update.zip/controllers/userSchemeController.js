const UserScheme = require("../models/UserScheme");


// ============================
// Create User Scheme
// ============================
exports.createUserScheme = async (req, res) => {
    try {

        const userScheme = await UserScheme.create(req.body);

        res.status(201).json({
            success: true,
            message: "User Scheme created successfully",
            data: userScheme
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


// ============================
// Get All User Schemes
// ============================
exports.getAllUserSchemes = async (req, res) => {
    try {

        const userSchemes = await UserScheme.find()
            .populate("user")
            .populate("scheme")
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: userSchemes.length,
            data: userSchemes
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


// ============================
// Get User Scheme By Id
// ============================
exports.getUserSchemeById = async (req, res) => {
    try {

        const userScheme = await UserScheme.findById(req.params.id)
            .populate("user")
            .populate("scheme");

        if (!userScheme) {
            return res.status(404).json({
                success: false,
                message: "User Scheme not found"
            });
        }

        res.status(200).json({
            success: true,
            data: userScheme
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


// ============================
// Update User Scheme
// ============================
exports.updateUserScheme = async (req, res) => {
    try {

        const userScheme = await UserScheme.findById(req.params.id);

        if (!userScheme) {
            return res.status(404).json({
                success: false,
                message: "User Scheme not found"
            });
        }

        const updatedScheme = await UserScheme.findByIdAndUpdate(
            req.params.id,
            req.body,
            {
                new: true,
                runValidators: true
            }
        );

        res.status(200).json({
            success: true,
            message: "User Scheme updated successfully",
            data: updatedScheme
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


// ============================
// Delete User Scheme
// ============================
exports.deleteUserScheme = async (req, res) => {
    try {

        const userScheme = await UserScheme.findById(req.params.id);

        if (!userScheme) {
            return res.status(404).json({
                success: false,
                message: "User Scheme not found"
            });
        }

        await UserScheme.findByIdAndDelete(req.params.id);

        res.status(200).json({
            success: true,
            message: "User Scheme deleted successfully"
        });

    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};