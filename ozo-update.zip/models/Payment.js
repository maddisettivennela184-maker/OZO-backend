const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    subscription: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "UserScheme",
      required: true
    },

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    monthNo: {
      type: Number,
      required: true
    },

    amount: {
      type: Number,
      required: true
    },

    paymentDate: {
      type: Date,
      required: true,
      default: Date.now
    },

    paymentMode: {
      type: String,
      enum: ["CASH", "UPI", "CARD", "NETBANKING"],
      required: true
    },

    transactionId: {
      type: String,
      default: null
    },

    status: {
      type: String,
      enum: ["PAID", "FAILED"],
      default: "PAID"
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("Payment", paymentSchema);