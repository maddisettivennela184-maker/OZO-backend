const mongoose = require("mongoose");

const userSchemeSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    scheme: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Scheme",
      required: true
    },

    schemeAmount: {
      type: Number,
      required: true
    },

    monthlyAmount: {
      type: Number,
      required: true
    },

    startDate: {
      type: Date,
      required: true
    },

    endDate: {
      type: Date,
      required: true
    },

    paidMonths: {
      type: Number,
      default: 0
    },

    status: {
      type: String,
      enum: ["ACTIVE", "COMPLETED", "PENDING"],
      default: "ACTIVE"
    }
  },
  {
    timestamps: true
  }
);

module.exports = mongoose.model("UserScheme", userSchemeSchema);