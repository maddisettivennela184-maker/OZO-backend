const mongoose = require("mongoose");

const cartSchema = new mongoose.Schema(
{
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  items: [
    {
      product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Product",
        required: true
      },

      variantId: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
      },

      quantity: {
        type: Number,
        default: 1
      }
    }
  ]
},
{
  timestamps: true
});

module.exports =
  mongoose.models.Cart ||
  mongoose.model("Cart", cartSchema);