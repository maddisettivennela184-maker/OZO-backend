const mongoose = require("mongoose");


const schemeSchema =
new mongoose.Schema({

 name:{
  type:String,
  required:true
 },

 amount:{
  type:Number,
  required:true
 },

 durationMonths:{
  type:Number,
  default:12
 },

 userPayMonths:{
  type:Number,
  default:11
 },

 companyPayMonths:{
  type:Number,
  default:1
 },

 monthlyAmount:{
  type:Number
 },

 description:String,

 isActive:{
  type:Boolean,
  default:true
 }

},
{
 timestamps:true
});


module.exports =
mongoose.model(
 "Scheme",
 schemeSchema
);